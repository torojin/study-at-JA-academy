package weekendstudyarray;
//�θ� Ŭ���� 
public class Family {
	//field(variable) ����
	private String name;
	
	//default constructor
	public Family() {
		super();
	}
	//parameter constructor
	public Family(String name) {
		super();
		this.name=name;
	}
	//toString
	@Override
	public String toString() {
		return "�̸� : "+name;
	}

}
