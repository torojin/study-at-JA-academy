package weekendstudyarray;
//interface ����
public interface Job {
	//interface method
	public String work();
}
